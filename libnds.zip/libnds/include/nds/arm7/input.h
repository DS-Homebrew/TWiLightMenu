#ifndef __INPUT_H__
#define __INPUT_H__

#ifdef __cplusplus
extern "C" {
#endif

void inputGetAndSend(void);

#ifdef __cplusplus
}
#endif

#endif
