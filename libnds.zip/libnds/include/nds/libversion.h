#ifndef __LIBNDSVERSION_H__
#define __LIBNDSVERSION_H__

#define _LIBNDS_MAJOR_	1
#define _LIBNDS_MINOR_	7
#define _LIBNDS_PATCH_	3

#define _LIBNDS_STRING "libNDS Release 1.7.3"

#endif // __LIBNDSVERSION_H__
