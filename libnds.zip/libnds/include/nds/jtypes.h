#error "jtypes.h is a deprecated header, use ndstypes.h"

#include "ndstypes.h"
